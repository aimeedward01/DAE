/** Automatically generated file. DO NOT MODIFY */
package com.eric.lelative_layout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}