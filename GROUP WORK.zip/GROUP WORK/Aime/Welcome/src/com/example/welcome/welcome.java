package com.example.welcome;

import android.content.Intent;
import android.os.Bundle;

public class welcome extends Activity {
protected void onCreate(Bundle save){
	super.onCreate(save);
	setContentView(R.layout.activity_main);
}

}
