package com.example.welcome;

import android.os.Bundle;

public class Activity {

	public void onCreate(Bundle save) {
		// TODO Auto-generated method stub
		
	}

}
