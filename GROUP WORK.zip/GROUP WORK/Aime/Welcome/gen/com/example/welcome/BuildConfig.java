/** Automatically generated file. DO NOT MODIFY */
package com.example.welcome;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}